#pragma once

/*
* Se porneste programul cu interfata de tip consola
* return - un meniu prin care utilizatorul poate sa aleaga
*		ce doreste sa execute programul
*/
void run();
#pragma once

/*
* Ruleaza toate functiile de test
* return - un mesaj pentru fiecare test rulat daca a fost
*		rulat cu succes sau Assertion Error in caz ca au
*		existat probleme
*/
void test_all();